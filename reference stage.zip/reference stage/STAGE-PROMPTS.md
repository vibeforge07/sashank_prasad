# Pictures for ChatGPT

The decorations stay as they are. Only the stage in each scene is redrawn: the client's stage in the site's own art style.

For each stage, open a **new** ChatGPT chat, attach the four pictures from its folder (A, B, C, D), and paste the prompt.
Save the result into `reference stage/done/` under the name given. I key the green and place it.

`0-where-it-goes/` shows each scene now (phone and desktop), so you can see what gets replaced. Do not attach those.

**Check before saving:** same pieces as A; ink outlines and flat colour like C; nothing but flat green around the stage; no people, text or watermark; the wedding stage has no sofa; the reception has no guest tables.

## Sangeet stage

Folder `1-sangeet/`, attach: `A-client-stage.png`, `B-style-reference.png`, `C-style-arches.png`, `D-style-candles.png`.
Save as `done/sangeet-stage-art.png`.

```
Redraw the stage in picture A in the art style of pictures B, C and D: a hand-drawn Indian wedding-invitation illustration with clean, confident dark-brown ink outlines of even weight, flat colour with soft cel shading and gentle gradients, rich jewel colours, and warm lights drawn as small glowing yellow dots with soft halos. Simple, bold shapes, like a premium storybook. No photorealism, no 3D-render look, no painterly texture.

Keep picture A's design exactly: the same layout, the same pieces in the same places, the same colours and flowers. Only the drawing style changes. Use B, C and D for the style only; do not copy anything else from them.

Picture A is the client's lavender-and-gold sangeet stage. Keep the big round golden ring with the flower garland across its top, the purple and lavender drapes with strings of tiny lights, the small gold lanterns hanging inside the ring, the cream-and-gold sofa with purple cushions in the middle, the flower vases on gold stands at both sides, and the stage floor with its patterned purple rug and front edge.

Leave out the spotlights on the floor and the big cream curtains at the far left and right edges. Leave some empty green above the top of the ring, because flower strands hang there on the site.

No people, no text, no letters, no watermark, no logo, no border.

Everything that is not part of the stage (sky, ceiling, room walls, the floor around it) is flat pure green #00FF00: one even colour with no shadow, glow or gradient on it, so the stage can be cut out. Leaves and plants are deep forest green, never bright lime.

Landscape 1536 x 1024. Front view at eye level, straight on, no tilt. The stage fills the full width and its front edge sits on the bottom edge of the picture.
```

## Wedding stage

Folder `2-wedding/`, attach: `A-client-stage.png`, `B-style-reference.png`, `C-style-palace.png`, `D-style-sofa-couple.png`.
Save as `done/wedding-stage-art.png`.

```
Redraw the stage in picture A in the art style of pictures B, C and D: a hand-drawn Indian wedding-invitation illustration with clean, confident dark-brown ink outlines of even weight, flat colour with soft cel shading and gentle gradients, rich jewel colours, and warm lights drawn as small glowing yellow dots with soft halos. Simple, bold shapes, like a premium storybook. No photorealism, no 3D-render look, no painterly texture.

Keep picture A's design exactly: the same layout, the same pieces in the same places, the same colours and flowers. Only the drawing style changes. Use B, C and D for the style only; do not copy anything else from them.

Picture A is the client's maroon-and-gold wedding stage. Keep the tall golden arch in the middle with its flower garlands, the golden lattice panels on both sides, the deep red velvet drapes, the strings of fairy lights, the hanging chandeliers, the flower urns on gold pedestals, the patterned rug and the stage edge.

Leave out the sofa completely: the middle of the stage is empty floor, because the couple sits there on their own sofa (the sofa in picture D, which is for style only). Leave out the spotlights on the floor.

The stage stands outdoors at night in front of a Kolkata and Jamshedpur skyline (drawn separately), so keep it compact: the stage takes the middle 60% of the width, and the left and right edges are green.

No people, no text, no letters, no watermark, no logo, no border.

Everything that is not part of the stage (sky, ceiling, room walls, the floor around it) is flat pure green #00FF00: one even colour with no shadow, glow or gradient on it, so the stage can be cut out. Leaves and plants are deep forest green, never bright lime.

Landscape 1536 x 1024. Front view at eye level, straight on, no tilt. The stage is centred and its front edge sits on the bottom edge of the picture.
```

## Wedding city backdrop (Kolkata + Jamshedpur)

Folder `4-wedding-city/`, attach: `A-kolkata-landmarks.png`, `B-jamshedpur-landmarks.png`, `C-style-night-buildings.png`, `D-style-reference.png`.
Save as `done/wedding-city-art.png`.

```
Art style: a hand-drawn Indian wedding-invitation illustration with clean, confident dark-brown ink outlines of even weight, flat colour with soft cel shading, rich jewel colours, and warm lights drawn as small glowing dots with soft halos, the same style as pictures A, B and C. Use the pictures for style and landmarks only.

This one is a new picture, not a redraw: a wide night skyline behind an outdoor wedding, where the bride's Kolkata meets the groom's Jamshedpur. Draw it like the lit buildings in picture C and the night in picture D: buildings glowing warm gold and orange against the night, small window lights, soft halos.

Left third, Kolkata: Howrah Bridge lit with strings of lights, drawn like picture A, and the white marble dome of the Victoria Memorial glowing softly beside it, with a few old Kolkata rooftops.

Right third, Jamshedpur: the Tata Steel plant with its red-and-white striped chimneys, warm furnace glow and soft white smoke, the glass diamond monument lit from inside, and the Dalma hills as dark blue-green shapes behind, all drawn like picture B.

Middle third: low, so the wedding stage can stand there. Only dark trees and a low hedge, nothing tall.

Across the whole bottom: a neat garden hedge full of tiny warm fairy lights, like the hedge in picture D, with marigold garlands and small brass diyas along its top so it reads as a wedding.

Night colours only: navy, deep teal, warm gold. No sun, no moon, no clouds, no river, no road, no vehicles. The sky above the skyline is flat green #00FF00.

No people, no text, no letters, no watermark, no logo, no border. Leaves are deep forest green, never bright lime.

Landscape 1536 x 1024, front view, straight on. The skyline fills the full width; the hedge sits on the bottom edge; the skyline takes the lower half of the picture and the green sky the upper half.
```

## Reception stage

Folder `3-reception/`, attach: `A-client-hall.png`, `B-style-reference.png`, `C-style-arch.png`, `D-style-lanterns.png`.
Save as `done/reception-stage-art.png`.

```
Redraw the stage in picture A in the art style of pictures B, C and D: a hand-drawn Indian wedding-invitation illustration with clean, confident dark-brown ink outlines of even weight, flat colour with soft cel shading and gentle gradients, rich jewel colours, and warm lights drawn as small glowing yellow dots with soft halos. Simple, bold shapes, like a premium storybook. No photorealism, no 3D-render look, no painterly texture.

Keep picture A's design exactly: the same layout, the same pieces in the same places, the same colours and flowers. Only the drawing style changes. Use B, C and D for the style only; do not copy anything else from them.

Picture A is the client's reception hall. Draw only the stage at the back of the hall: the flower arch, the cream lattice screens, the golden sofa on its platform, the chandelier above it, the cream and red drapes with fairy lights, and the tall candles and flower urns.

Leave out all the round guest tables and chairs, and the aisle carpet. The couple and their feast table stand in front of this stage on the site, and lanterns like picture D hang at its sides.

No people, no text, no letters, no watermark, no logo, no border.

Everything that is not part of the stage (sky, ceiling, room walls, the floor around it) is flat pure green #00FF00: one even colour with no shadow, glow or gradient on it, so the stage can be cut out. Leaves and plants are deep forest green, never bright lime.

Landscape 1536 x 1024. Front view at eye level, straight on, no tilt. The stage fills the full width and its front edge sits on the bottom edge of the picture.
```

# New clothes for the couple

A different outfit for every event, casual on the first page. The wedding and the reception stay as they are.
One new ChatGPT chat per picture: attach the picture(s) from its folder, paste the prompt, save into `done/` under the name given.

**Check before saving:** same faces and pose as now; only the clothes changed; no crown except at the wedding; flat background.

## First page: the groom, casual

Folder `5-first-page/`, attach: `A-groom-now.png`, `B-bride-now.png`.
Save as `done/hero-groom.png`.

```
Draw the man in picture A again, in the same art style (dark-brown ink outlines, flat colour, soft cel shading) and with the same face, hair and skin. Full body, standing, from head to shoes, feet near the bottom edge.

He is dressed casually for an everyday outing, not for a wedding: a sky-blue linen shirt with the sleeves rolled to the elbows, beige chinos, brown loafers and a simple wristwatch. No topor, no turban, no garland, no dupatta, no tilak.

He stands turned three-quarters towards the right edge of the picture, looking to the right with a warm smile, as if at his bride standing beside him. One hand in his trouser pocket, the other relaxed at his side.

Background: flat pure green #00FF00, one even colour with no shadow or gradient. No text, no watermark, no border. Portrait 1024 x 1536.
```

## First page: the bride, casual

Folder `5-first-page/`, attach: `A-groom-now.png`, `B-bride-now.png`.
Save as `done/hero-bride.png`.

```
Draw the woman in picture B again, in the same art style (dark-brown ink outlines, flat colour, soft cel shading) and with the same face, hair and skin. Full body, standing, from head to shoes, feet near the bottom edge.

She is dressed casually for an everyday outing, not as a bride: a mustard-yellow cotton kurta with small white block prints, white palazzo trousers, a light peach dupatta over one shoulder, small silver jhumkas, a few glass bangles, a small red bindi, hair open and wavy. No crown, no mukut, no veil, no garland, no red bridal saree, no heavy jewellery.

She stands turned three-quarters towards the left edge of the picture, looking to the left with a shy smile, as if at her groom standing beside her. Both hands lightly hold the end of her dupatta.

Draw her the same height as the man in picture A.

Background: flat pure green #00FF00, one even colour with no shadow or gradient. No text, no watermark, no border. Portrait 1024 x 1536.
```

## Tilak: the groom

Folder `6-tilak/`, attach: `A-now.png`.
Save as `done/tilak-groom.png`.

```
Edit picture A. Keep everything exactly as it is: the same people, the same faces, hair and skin, the same pose, hands and expression, the same size and position in the frame, and the same art style (dark-brown ink outlines, flat colour, soft cel shading). Change only the clothes and jewellery, as follows:

He wears a bottle-green raw-silk kurta with small gold buttons and a thin gold border at the collar, an off-white dhoti, and a thin cream stole over one shoulder. No cream kurta, no orange or red dupatta.

Background: flat pure blue #0000FF, one even colour with no shadow or gradient. No text, no watermark, no border. Same picture size as A.
```

## Briddhi: the bride

Folder `7-briddhi/`, attach: `A-now.png`.
Save as `done/briddhi-family.png`.

```
Edit picture A. Keep everything exactly as it is: the same people, the same faces, hair and skin, the same pose, hands and expression, the same size and position in the frame, and the same art style (dark-brown ink outlines, flat colour, soft cel shading). Change only the clothes and jewellery, as follows:

Change only the bride (the young woman with the crown and the red veil). She now wears a pale pink cotton tant saree with a thin gold border, simple gold studs, a thin gold chain and a few bangles, hair in a low bun with a small string of jasmine. No crown, no mukut, no veil, no red bridal saree. Everyone else stays exactly the same.

Background: flat pure blue #0000FF, one even colour with no shadow or gradient. No text, no watermark, no border. Same picture size as A.
```

## Mehendi: the couple

Folder `8-mehendi/`, attach: `A-now.png`.
Save as `done/mehendi-couple.png`.

```
Edit picture A. Keep everything exactly as it is: the same people, the same faces, hair and skin, the same pose, hands and expression, the same size and position in the frame, and the same art style (dark-brown ink outlines, flat colour, soft cel shading). Change only the clothes and jewellery, as follows:

The bride wears a parrot-green lehenga with small mirror work and a pink dupatta, fresh-flower jewellery of marigold and jasmine, hair in a loose braid. No crown, no mukut, no veil, no red saree.

The groom wears a peach cotton kurta with a white churidar. No cream kurta, no yellow or orange dupatta.

Background: flat pure blue #0000FF, one even colour with no shadow or gradient. No text, no watermark, no border. Same picture size as A.
```

## Aiburobhaat: the bride

Folder `9-aiburobhaat/`, attach: `A-now.png`.
Save as `done/aibur-family.png`.

```
Edit picture A. Keep everything exactly as it is: the same people, the same faces, hair and skin, the same pose, hands and expression, the same size and position in the frame, and the same art style (dark-brown ink outlines, flat colour, soft cel shading). Change only the clothes and jewellery, as follows:

Change only the bride (the young woman in the middle with the crown). She now wears a deep magenta Banarasi silk saree with gold zari, gold jewellery, hair in a bun with a jasmine gajra. No crown, no mukut, no veil. Everyone else stays exactly the same.

Background: flat pure green #00FF00, one even colour with no shadow or gradient. No text, no watermark, no border. Same picture size as A.
```

## Haldi: the couple

Folder `10-haldi/`, attach: `A-now.png`.
Save as `done/haldi-couple-full.png`.

```
Edit picture A. Keep everything exactly as it is: the same people, the same faces, hair and skin, the same pose, hands and expression, the same size and position in the frame, and the same art style (dark-brown ink outlines, flat colour, soft cel shading). Change only the clothes and jewellery, as follows:

Both are dressed for haldi. The groom wears a plain yellow cotton kurta and a white pyjama, with no red or orange dupatta. The bride wears a yellow-and-white cotton saree with fresh-flower jewellery of marigold and jasmine, hair in a loose bun with flowers. No crown, no mukut, no veil.

Keep the groom's arm, his hand and the haldi bowl exactly where they are now.

Background: flat pure blue #0000FF, one even colour with no shadow or gradient. No text, no watermark, no border. Same picture size as A.
```

## Sangeet: the bride

Folder `11-sangeet-bride/`, attach: `A-now.png`.
Save as `done/sangeet-bride.png`.

```
Edit picture A. Keep everything exactly as it is: the same people, the same faces, hair and skin, the same pose, hands and expression, the same size and position in the frame, and the same art style (dark-brown ink outlines, flat colour, soft cel shading). Change only the clothes and jewellery, as follows:

She wears a lavender-and-silver lehenga with mirror work and a sheer lilac dupatta flying with the dance, silver jhumkas, hair open and flying with jasmine in it. No crown, no mukut, no red lehenga.

Background: flat pure green #00FF00, one even colour with no shadow or gradient. No text, no watermark, no border. Same picture size as A.
```
