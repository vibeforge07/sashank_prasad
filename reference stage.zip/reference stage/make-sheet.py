import io, html, json
R = 'E:/client work/shasank_prasad/reference stage/'
STYLE = ("Redraw the stage in picture A in the art style of pictures B, C and D: a hand-drawn Indian wedding-invitation illustration "
 "with clean, confident dark-brown ink outlines of even weight, flat colour with soft cel shading and gentle gradients, rich jewel colours, "
 "and warm lights drawn as small glowing yellow dots with soft halos. Simple, bold shapes, like a premium storybook. "
 "No photorealism, no 3D-render look, no painterly texture.\n\n"
 "Keep picture A's design exactly: the same layout, the same pieces in the same places, the same colours and flowers. Only the drawing style changes. "
 "Use B, C and D for the style only; do not copy anything else from them.\n\n")
TAIL = ("\n\nNo people, no text, no letters, no watermark, no logo, no border.\n\n"
 "Everything that is not part of the stage (sky, ceiling, room walls, the floor around it) is flat pure green #00FF00: one even colour "
 "with no shadow, glow or gradient on it, so the stage can be cut out. Leaves and plants are deep forest green, never bright lime.\n\n"
 "Landscape 1536 x 1024. Front view at eye level, straight on, no tilt. The stage fills the full width and its front edge "
 "sits on the bottom edge of the picture.")
ITEMS = [
 ('1-sangeet', 'Sangeet stage', 'sangeet-stage-art.png',
  ['A-client-stage.png', 'B-style-reference.png', 'C-style-arches.png', 'D-style-candles.png'],
  "Picture A is the client's lavender-and-gold sangeet stage. Keep the big round golden ring with the flower garland across its top, "
  "the purple and lavender drapes with strings of tiny lights, the small gold lanterns hanging inside the ring, the cream-and-gold sofa "
  "with purple cushions in the middle, the flower vases on gold stands at both sides, and the stage floor with its patterned purple rug "
  "and front edge.\n\n"
  "Leave out the spotlights on the floor and the big cream curtains at the far left and right edges. "
  "Leave some empty green above the top of the ring, because flower strands hang there on the site."),
 ('2-wedding', 'Wedding stage', 'wedding-stage-art.png',
  ['A-client-stage.png', 'B-style-reference.png', 'C-style-palace.png', 'D-style-sofa-couple.png'],
  "Picture A is the client's maroon-and-gold wedding stage. Keep the tall golden arch in the middle with its flower garlands, "
  "the golden lattice panels on both sides, the deep red velvet drapes, the strings of fairy lights, the hanging chandeliers, "
  "the flower urns on gold pedestals, the patterned rug and the stage edge.\n\n"
  "Leave out the sofa completely: the middle of the stage is empty floor, because the couple sits there on their own sofa "
  "(the sofa in picture D, which is for style only). Leave out the spotlights on the floor.\n\n"
  "The stage stands outdoors at night in front of a Kolkata and Jamshedpur skyline (drawn separately), so keep it compact: "
  "the stage takes the middle 60% of the width, and the left and right edges are green."),
 ('4-wedding-city', 'Wedding city backdrop (Kolkata + Jamshedpur)', 'wedding-city-art.png',
  ['A-kolkata-landmarks.png', 'B-jamshedpur-landmarks.png', 'C-style-night-buildings.png', 'D-style-reference.png'],
  "This one is a new picture, not a redraw: a wide night skyline behind an outdoor wedding, where the bride's Kolkata meets the "
  "groom's Jamshedpur. Draw it like the lit buildings in picture C and the night in picture D: buildings glowing warm gold and "
  "orange against the night, small window lights, soft halos.\n\n"
  "Left third, Kolkata: Howrah Bridge lit with strings of lights, drawn like picture A, and the white marble dome of the "
  "Victoria Memorial glowing softly beside it, with a few old Kolkata rooftops.\n\n"
  "Right third, Jamshedpur: the Tata Steel plant with its red-and-white striped chimneys, warm furnace glow and soft white smoke, "
  "the glass diamond monument lit from inside, and the Dalma hills as dark blue-green shapes behind, all drawn like picture B.\n\n"
  "Middle third: low, so the wedding stage can stand there. Only dark trees and a low hedge, nothing tall.\n\n"
  "Across the whole bottom: a neat garden hedge full of tiny warm fairy lights, like the hedge in picture D, with marigold "
  "garlands and small brass diyas along its top so it reads as a wedding.\n\n"
  "Night colours only: navy, deep teal, warm gold. No sun, no moon, no clouds, no river, no road, no vehicles. "
  "The sky above the skyline is flat green #00FF00."),
 ('3-reception', 'Reception stage', 'reception-stage-art.png',
  ['A-client-hall.png', 'B-style-reference.png', 'C-style-arch.png', 'D-style-lanterns.png'],
  "Picture A is the client's reception hall. Draw only the stage at the back of the hall: the flower arch, the cream lattice screens, "
  "the golden sofa on its platform, the chandelier above it, the cream and red drapes with fairy lights, and the tall candles and "
  "flower urns.\n\n"
  "Leave out all the round guest tables and chairs, and the aisle carpet. The couple and their feast table stand in front of this "
  "stage on the site, and lanterns like picture D hang at its sides."),
]
md = ["# Stage pictures for ChatGPT", "",
 "The decorations stay as they are. Only the stage in each scene is redrawn: the client's stage in the site's own art style.", "",
 "For each stage, open a **new** ChatGPT chat, attach the four pictures from its folder (A, B, C, D), and paste the prompt.",
 "Save the result into `reference stage/done/` under the name given. I key the green and place it.", "",
 "`0-where-it-goes/` shows each scene now (phone and desktop), so you can see what gets replaced. Do not attach those.", "",
 "**Check before saving:** same pieces as A; ink outlines and flat colour like C; nothing but flat green around the stage; "
 "no people, text or watermark; the wedding stage has no sofa; the reception has no guest tables.", ""]
cards = []
for folder, title, out, files, body in ITEMS:
    if folder == '4-wedding-city':
        prompt = ("Art style: a hand-drawn Indian wedding-invitation illustration with clean, confident dark-brown ink outlines of even weight, "
          "flat colour with soft cel shading, rich jewel colours, and warm lights drawn as small glowing dots with soft halos, the same style "
          "as pictures A, B and C. Use the pictures for style and landmarks only.\n\n" + body +
          "\n\nNo people, no text, no letters, no watermark, no logo, no border. Leaves are deep forest green, never bright lime.\n\n"
          "Landscape 1536 x 1024, front view, straight on. The skyline fills the full width; the hedge sits on the bottom edge; "
          "the skyline takes the lower half of the picture and the green sky the upper half.")
    elif folder == '2-wedding':
        prompt = STYLE + body + TAIL.replace('The stage fills the full width and its front edge', 'The stage is centred and its front edge')
    else:
        prompt = STYLE + body + TAIL
    md += [f"## {title}", "", f"Folder `{folder}/`, attach: " + ", ".join(f"`{f}`" for f in files) + ".", f"Save as `done/{out}`.", "",
           "```", prompt, "```", ""]
    thumbs = ''.join(f'<figure><img src="{folder}/{f}" alt=""><figcaption>{f}</figcaption></figure>' for f in files)
    cards.append(f'<section><h2>{html.escape(title)}</h2><p>Attach these four from <b>{folder}/</b>, then paste the prompt. Save as <b>done/{out}</b>.</p>'
                 f'<div class="thumbs">{thumbs}</div><button data-p="{html.escape(prompt, quote=True)}">Copy prompt</button><pre>{html.escape(prompt)}</pre></section>')
# ---- new clothes: a different outfit for every event, casual on the first page ----
EDIT = ("Edit picture A. Keep everything exactly as it is: the same people, the same faces, hair and skin, the same pose, "
        "hands and expression, the same size and position in the frame, and the same art style (dark-brown ink outlines, "
        "flat colour, soft cel shading). Change only the clothes and jewellery, as follows:\n\n{change}\n\n"
        "Background: flat pure {bg}, one even colour with no shadow or gradient. No text, no watermark, no border. "
        "Same picture size as A.")
NEW = ("Draw the {who} in picture {pic} again, in the same art style (dark-brown ink outlines, flat colour, soft cel shading) "
       "and with the same face, hair and skin. Full body, standing, from head to shoes, feet near the bottom edge.\n\n{body}\n\n"
       "Background: flat pure green #00FF00, one even colour with no shadow or gradient. No text, no watermark, no border. "
       "Portrait 1024 x 1536.")
GREEN, BLUE = 'green #00FF00', 'blue #0000FF'
OUTFITS = [
 ('5-first-page', 'First page: the groom, casual', 'hero-groom.png', ['A-groom-now.png', 'B-bride-now.png'],
  NEW.format(who='man', pic='A', body=
  "He is dressed casually for an everyday outing, not for a wedding: a sky-blue linen shirt with the sleeves rolled to the "
  "elbows, beige chinos, brown loafers and a simple wristwatch. No topor, no turban, no garland, no dupatta, no tilak.\n\n"
  "He stands turned three-quarters towards the right edge of the picture, looking to the right with a warm smile, as if at "
  "his bride standing beside him. One hand in his trouser pocket, the other relaxed at his side.")),
 ('5-first-page', 'First page: the bride, casual', 'hero-bride.png', ['A-groom-now.png', 'B-bride-now.png'],
  NEW.format(who='woman', pic='B', body=
  "She is dressed casually for an everyday outing, not as a bride: a mustard-yellow cotton kurta with small white block "
  "prints, white palazzo trousers, a light peach dupatta over one shoulder, small silver jhumkas, a few glass bangles, "
  "a small red bindi, hair open and wavy. No crown, no mukut, no veil, no garland, no red bridal saree, no heavy jewellery.\n\n"
  "She stands turned three-quarters towards the left edge of the picture, looking to the left with a shy smile, as if at "
  "her groom standing beside her. Both hands lightly hold the end of her dupatta.\n\n"
  "Draw her the same height as the man in picture A.")),
 ('6-tilak', 'Tilak: the groom', 'tilak-groom.png', ['A-now.png'],
  EDIT.format(bg=BLUE, change=
  "He wears a bottle-green raw-silk kurta with small gold buttons and a thin gold border at the collar, an off-white dhoti, "
  "and a thin cream stole over one shoulder. No cream kurta, no orange or red dupatta.")),
 ('7-briddhi', 'Briddhi: the bride', 'briddhi-family.png', ['A-now.png'],
  EDIT.format(bg=BLUE, change=
  "Change only the bride (the young woman with the crown and the red veil). She now wears a pale pink cotton tant saree "
  "with a thin gold border, simple gold studs, a thin gold chain and a few bangles, hair in a low bun with a small string "
  "of jasmine. No crown, no mukut, no veil, no red bridal saree. Everyone else stays exactly the same.")),
 ('8-mehendi', 'Mehendi: the couple', 'mehendi-couple.png', ['A-now.png'],
  EDIT.format(bg=BLUE, change=
  "The bride wears a parrot-green lehenga with small mirror work and a pink dupatta, fresh-flower jewellery of marigold "
  "and jasmine, hair in a loose braid. No crown, no mukut, no veil, no red saree.\n\n"
  "The groom wears a peach cotton kurta with a white churidar. No cream kurta, no yellow or orange dupatta.")),
 ('9-aiburobhaat', 'Aiburobhaat: the bride', 'aibur-family.png', ['A-now.png'],
  EDIT.format(bg=GREEN, change=
  "Change only the bride (the young woman in the middle with the crown). She now wears a deep magenta Banarasi silk saree "
  "with gold zari, gold jewellery, hair in a bun with a jasmine gajra. No crown, no mukut, no veil. Everyone else stays "
  "exactly the same.")),
 ('10-haldi', 'Haldi: the couple', 'haldi-couple-full.png', ['A-now.png'],
  EDIT.format(bg=BLUE, change=
  "Both are dressed for haldi. The groom wears a plain yellow cotton kurta and a white pyjama, with no red or orange "
  "dupatta. The bride wears a yellow-and-white cotton saree with fresh-flower jewellery of marigold and jasmine, hair in a "
  "loose bun with flowers. No crown, no mukut, no veil.\n\n"
  "Keep the groom's arm, his hand and the haldi bowl exactly where they are now.")),
 ('11-sangeet-bride', 'Sangeet: the bride', 'sangeet-bride.png', ['A-now.png'],
  EDIT.format(bg=GREEN, change=
  "She wears a lavender-and-silver lehenga with mirror work and a sheer lilac dupatta flying with the dance, silver jhumkas, "
  "hair open and flying with jasmine in it. No crown, no mukut, no red lehenga.")),
]
md += ["# New clothes for the couple", "",
       "A different outfit for every event, casual on the first page. The wedding and the reception stay as they are.",
       "One new ChatGPT chat per picture: attach the picture(s) from its folder, paste the prompt, save into `done/` under the name given.", "",
       "**Check before saving:** same faces and pose as now; only the clothes changed; no crown except at the wedding; flat background.", ""]
cards.append('<h1 style="margin-top:40px">New clothes for the couple</h1><p>A different outfit for every event, casual on the first page. Wedding and reception stay. One new ChatGPT chat per picture. Check: same faces and pose, only the clothes changed, no crown except at the wedding, flat background.</p>')
for folder, title, out, files, prompt in OUTFITS:
    md += [f"## {title}", "", f"Folder `{folder}/`, attach: " + ", ".join(f"`{f}`" for f in files) + ".", f"Save as `done/{out}`.", "",
           "```", prompt, "```", ""]
    thumbs = ''.join(f'<figure><img src="{folder}/{f}" alt=""><figcaption>{f}</figcaption></figure>' for f in files)
    cards.append(f'<section><h2>{html.escape(title)}</h2><p>Attach from <b>{folder}/</b>, then paste the prompt. Save as <b>done/{out}</b>.</p>'
                 f'<div class="thumbs">{thumbs}</div><button data-p="{html.escape(prompt, quote=True)}">Copy prompt</button><pre>{html.escape(prompt)}</pre></section>')
md[0] = "# Pictures for ChatGPT"
io.open(R + 'STAGE-PROMPTS.md', 'w', encoding='utf-8', newline='\n').write('\n'.join(md))
page = f'''<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>ChatGPT prompts</title>
<style>body{{font:16px/1.5 system-ui,sans-serif;margin:0;background:#f6f1e7;color:#2a1d16}}main{{max-width:980px;margin:auto;padding:24px 16px}}
section{{background:#fff;border:1px solid #e2d5bd;border-radius:12px;padding:18px;margin:18px 0}}h1{{margin:0 0 6px}}h2{{margin:0 0 6px}}
.thumbs{{display:grid;grid-template-columns:repeat(4,1fr);gap:10px;margin:12px 0}}figure{{margin:0}}img{{width:100%;height:150px;object-fit:contain;background:#eee;border-radius:6px}}
figcaption{{font-size:12px;color:#7a6a5a}}pre{{white-space:pre-wrap;background:#faf6ee;border-radius:8px;padding:12px;font:14px/1.5 ui-monospace,monospace}}
button{{background:#7a1f2b;color:#fff;border:0;border-radius:8px;padding:9px 16px;font-size:15px;cursor:pointer}}
@media(max-width:600px){{.thumbs{{grid-template-columns:repeat(2,1fr)}}}}</style></head><body><main>
<h1>Pictures for ChatGPT</h1><h2 style="margin-top:20px">Stages</h2><p>The decorations stay. Only the stage is redrawn: the client's stage in the site's art style. One new ChatGPT chat per stage. Check: same pieces as A, ink and flat colour like C, flat green around it, no people or text, no sofa on the wedding stage, no guest tables in the reception.</p>
{''.join(cards)}</main><script>document.querySelectorAll('button').forEach(b=>b.onclick=()=>navigator.clipboard.writeText(b.dataset.p).then(()=>{{b.textContent='Copied';setTimeout(()=>b.textContent='Copy prompt',1500)}}))</script></body></html>'''
io.open(R + 'sheet.html', 'w', encoding='utf-8', newline='\n').write(page)
print('ok')
