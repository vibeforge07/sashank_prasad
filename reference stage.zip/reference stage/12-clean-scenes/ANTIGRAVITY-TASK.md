# Task for Antigravity: 10 pictures for the Sangeet, Wedding and Reception scenes

This is a wedding invitation website. The client loves two of its scenes, Mehendi and Haldi (`style/S3-mehendi-whole-look.png`, `style/S4-haldi-whole-look.png`). Both have:

- a clean, plain sky;
- the words written in the clean middle;
- decorations coming in from the top, from both sides and from the bottom;
- a small stage piece at the bottom middle, with the couple in front of it.

Sangeet, Wedding and Reception are being rebuilt the same way. **You only make the pictures.** Claude places them in the site afterwards.

Look at these to understand the job, but **never attach them**:

- `style/S3-mehendi-whole-look.png` and `style/S4-haldi-whole-look.png`: the look the client wants.
- `<scene>/D-now.png`: how each scene looks now, which is not wanted.
- `<scene>/E-plan-phone.png`: where each new picture goes on a phone (red = new picture, green = stays).

## Files you may touch

| Path | What you may do |
|---|---|
| `reference stage/done/<name>.png`, only for the 10 names below | create, replace |
| `reference stage/12-clean-scenes/` | read and attach only |

## Off limits

- Everything else in the project. That includes:
  - `src/`, `scripts/`, `art/`, `public/`;
  - `index.html`, `package.json`, `package-lock.json`, `vite.config.js`;
  - the other folders in `reference stage/`;
  - the three files already in `reference stage/done/` (`sangeet-stage-art.png`, `wedding-stage-art.png`, `reception-stage-art.png`).
- Do not edit code. Do not install packages. Do not run npm.
- Do not delete or rename anything.
- Run no git commands at all. This folder is not in git.
- Never draw people in any picture.

## How to make each picture

1. Use a fresh generation for each picture.
2. Attach the files the block names, in that order. If your image tool cannot take image attachments, **stop and say so**. Do not continue from text alone.
3. Paste the block word for word.
4. Save the picture as PNG at the largest size your tool gives, at `reference stage/done/<name>.png`.
5. Check the picture against the list below. If it fails, regenerate. Make at most 3 tries per picture, then keep the best one and say what is wrong with it.

## Checkpoint

Make **1 `sangeet-stage-small`** and **2 `sangeet-drape`** first. Then **STOP**: show me both with your check results and wait for my OK. After my OK, make 3 to 10 in order without stopping, and finish with a short report: each file name and pass, or what is wrong.

## Check every picture before saving

1. **Line and colour:** bold, clean black outlines of even weight and flat colours, exactly like S1 and S2. Crisp edges: nothing blurry, hazy, glowing or painterly.
2. **Stands alone:** the piece has no room, wall, ceiling, sky, floor or curtain running out to the picture edge. The only exceptions are the drapes and the hanging strips, which touch the edges their block names.
3. **Clean background:** everything else is ONE flat key colour, with no shadow, glow, gradient, floor line or reflection on it.
4. **Nothing cut off:** no part of the piece is cut by the picture edge, except where the block says it should touch.
5. **Nothing extra:** no people, no text, letters, numbers, watermark, logo, border or frame.
6. **Stage pieces only:** the same design pieces as A and B, drawn as one compact piece.

---

## 1. `sangeet-stage-small` (green key)

Attach: `style/S1-haldi-backdrop.png`, `sangeet/A-client-stage.png`, `sangeet/B-stage-in-our-style.png`

```
Draw the client's lavender-and-gold Sangeet stage as one small stage piece standing on its own, in the same way picture S1 shows the Haldi backdrop as a single piece. Picture A is the client's real stage; picture B is the same stage already redrawn in our site's style. Keep the design of A and B, but no room around it: no curtains running out to the edges, no wall, no ceiling, no floor around it.

Keep these pieces: the big round golden ring (a moon gate) with a garland of lavender, purple and cream flowers over its top-left; four small gold globe lanterns hanging inside the ring; a lavender drape filling the inside of the ring with a few strings of tiny warm lights; a flower vase on a slim gold stand on each side of the ring; a small gold cage lantern with a lit candle on each side; a low stage platform with a purple patterned rug and a gold front edge. Leave out the sofa, because the couple dances in front of the stage.

Art style: copy the drawing style of picture S1 exactly. A hand-drawn Bengali wedding-invitation illustration: bold, clean black ink outlines of even weight around every shape, flat bright colours with at most one soft shade per colour, crisp folk-art patterns (small flowers, dots, stripes, borders) drawn as clear shapes, warm lights as small yellow dots. Big simple shapes, sharp edges. Nothing blurry, no glow haze, no painterly texture, no photorealism, no 3D-render look, no tiny noisy detail. The light on the stage is warm, never tinted green.

Front view at eye level, straight on, centred. The stage piece fills about 85% of the picture width, with an even band of background on all four sides; nothing touches the picture edges.

Everything around the stage piece is flat pure green #00FF00: one even colour with no shadow, glow, floor or gradient on it, so it can be cut out. Leaves are deep forest green, never bright lime.

No people, no text, no letters, no numbers, no watermark, no logo, no border. Landscape 3:2.
```

## 2. `sangeet-drape` (green key)

Attach: `style/S2-haldi-drape.png`, `style/S1-haldi-backdrop.png`, `sangeet/C-stays-hanging-strands.png`

```
Draw one silk drape for the top-left corner of a screen, made the same way as the drape in picture S2: lavender silk falling from the top edge, gathered about halfway down by a gold rope with a big gold tassel, then falling in soft folds to a point. A string of white jasmine and small purple flowers hangs along its inner (right) edge, with a few warm light dots. A thin gold border runs along its hem. Its colours must sit well with the flower strands in the third picture, which hang across the top of the same scene.

Art style: copy the drawing style of pictures S1 and S2 exactly. A hand-drawn Bengali wedding-invitation illustration: bold, clean black ink outlines of even weight around every shape, flat bright colours with at most one soft shade per colour, crisp folk-art patterns drawn as clear shapes. Big simple shapes, sharp edges. Nothing blurry, no glow haze, no painterly texture, no photorealism, no 3D-render look.

The drape touches the top edge and the left edge of the picture and hangs down to about 85% of the picture height. It is a left-corner piece; the site mirrors it for the right corner.

Everything else is flat pure green #00FF00: one even colour with no shadow, glow or gradient on it, so it can be cut out.

No people, no text, no letters, no watermark, no logo, no border. Portrait 9:16.
```

## 3. `wedding-stage-small` (blue key)

Attach: `style/S1-haldi-backdrop.png`, `wedding/A-client-stage.png`, `wedding/B-stage-in-our-style.png`

```
Draw the client's maroon-and-gold wedding stage as one small stage piece standing on its own, in the same way picture S1 shows the Haldi backdrop as a single piece. Picture A is the client's real stage; picture B is the same stage already redrawn in our site's style. Keep the design of A and B, but no room around it: no big curtains at the outer edges, no wall, no ceiling, no floor around it.

Keep these pieces: the tall central gold arch with a thick garland of red, cream and white flowers over it; three gold lanterns hanging inside the arch over a maroon drape with strings of tiny warm lights; a smaller gold lattice arch on each side with a spray of flowers on top; a flower vase on a brass stand at each side; a low stage platform with a red-and-cream patterned rug and a maroon front edge. Leave out the sofa, because the seated couple has their own sofa in front of the stage.

Art style: copy the drawing style of picture S1 exactly. A hand-drawn Bengali wedding-invitation illustration: bold, clean black ink outlines of even weight around every shape, flat bright colours with at most one soft shade per colour, crisp folk-art patterns (small flowers, dots, stripes, borders) drawn as clear shapes, warm lights as small yellow dots. Big simple shapes, sharp edges. Nothing blurry, no glow haze, no painterly texture, no photorealism, no 3D-render look, no tiny noisy detail. The light on the stage is warm, never tinted blue.

Front view at eye level, straight on, centred. The stage piece fills about 85% of the picture width, with an even band of background on all four sides; nothing touches the picture edges.

Everything around the stage piece is flat pure blue #0000FF: one even colour with no shadow, glow, floor or gradient on it, so it can be cut out. Nothing on the stage itself is blue.

No people, no text, no letters, no numbers, no watermark, no logo, no border. Landscape 3:2.
```

## 4. `wedding-drape` (green key)

Attach: `style/S2-haldi-drape.png`, `style/S1-haldi-backdrop.png`, `wedding/B-stage-in-our-style.png`

```
Draw one velvet drape for the top-left corner of a screen, made the same way as the drape in picture S2: deep maroon velvet falling from the top edge with a wide gold border band, gathered about halfway down by a thick gold rope with a gold tassel, then falling in folds to a point. A string of orange and yellow marigolds with small brass bells hangs along its inner (right) edge. Its colours match the maroon-and-gold stage in the third picture.

Art style: copy the drawing style of pictures S1 and S2 exactly. A hand-drawn Bengali wedding-invitation illustration: bold, clean black ink outlines of even weight around every shape, flat bright colours with at most one soft shade per colour, crisp folk-art patterns drawn as clear shapes. Big simple shapes, sharp edges. Nothing blurry, no glow haze, no painterly texture, no photorealism, no 3D-render look.

The drape touches the top edge and the left edge of the picture and hangs down to about 85% of the picture height. It is a left-corner piece; the site mirrors it for the right corner.

Everything else is flat pure green #00FF00: one even colour with no shadow, glow or gradient on it, so it can be cut out.

No people, no text, no letters, no watermark, no logo, no border. Portrait 9:16.
```

## 5. `wedding-hanging` (blue key)

Attach: `style/S1-haldi-backdrop.png`, `style/S2-haldi-drape.png`, `wedding/B-stage-in-our-style.png`

```
Draw a Bengali wedding toran that runs across the top edge of a screen: a gold rope across the very top, with even swags of orange and yellow marigold garlands hanging from it, green mango leaves set along the rope, and a small brass bell hanging at the bottom of every swag. Five even swags across the width.

Art style: copy the drawing style of pictures S1 and S2 exactly. A hand-drawn Bengali wedding-invitation illustration: bold, clean black ink outlines of even weight around every shape, flat bright colours with at most one soft shade per colour. Big simple shapes, sharp edges. Nothing blurry, no glow haze, no painterly texture, no photorealism, no 3D-render look.

The rope touches the top edge and runs out through the left and right edges. The swags dip to about 60% of the picture height; below them is only background. The left and right ends match, so the strip can repeat side by side.

Everything else is flat pure blue #0000FF: one even colour with no shadow, glow or gradient on it, so it can be cut out. Nothing in the toran is blue.

No people, no text, no letters, no watermark, no logo, no border. Very wide: 21:9 (16:9 if 21:9 is not available).
```

## 6. `wedding-banana` (blue key)

Attach: `style/S1-haldi-backdrop.png`, `style/S2-haldi-drape.png`, `wedding/B-stage-in-our-style.png`

```
Draw the banana plant that stands at the corner of a Bengali wedding mandap (kola gachh), as one piece standing on its own: a young banana plant with a few big, clean green leaves, standing in a round brass pot painted with white alpana dots, with a marigold garland tied around its stem. At its foot: a brass mangal ghot (a round pot with five mango leaves and a green coconut on top, marked with a red sindoor dot) and one small lit brass diya.

Art style: copy the drawing style of pictures S1 and S2 exactly. A hand-drawn Bengali wedding-invitation illustration: bold, clean black ink outlines of even weight around every shape, flat bright colours with at most one soft shade per colour, crisp folk-art patterns drawn as clear shapes. Big simple shapes, sharp edges. Nothing blurry, no glow haze, no painterly texture, no photorealism, no 3D-render look.

Front view, straight on. The whole piece is visible, from the leaf tips to the bottom of the pot, with an even band of background around it; nothing touches the picture edges. No floor and no shadow under it.

Everything around it is flat pure blue #0000FF: one even colour with no shadow, glow or gradient on it, so it can be cut out. Nothing in the piece is blue.

No people, no text, no letters, no watermark, no logo, no border. Portrait 2:3.
```

## 7. `reception-stage-small` (blue key)

Attach: `style/S1-haldi-backdrop.png`, `reception/A-client-stage.png`, `reception/B-stage-in-our-style.png`

```
Draw the client's reception stage as one small stage piece standing on its own, in the same way picture S1 shows the Haldi backdrop as a single piece. Picture A is the client's real reception hall; picture B is its stage already redrawn in our site's style. Keep the stage's design, but no room around it: no ceiling drapes, no side curtains, no chandelier, no guest tables, no wall, no floor around it.

Keep these pieces: a big arch of red, pink and white lilies and roses with dark green leaves; three small gold lanterns hanging inside the arch over a deep maroon drape with strings of tiny warm lights; ivory lattice screens with rounded tops on both sides of the arch; white flower urns on ivory pedestals; little clusters of white candles; an ivory-and-gold sofa with two maroon cushions in the middle; a low maroon stage platform.

Art style: copy the drawing style of picture S1 exactly. A hand-drawn Bengali wedding-invitation illustration: bold, clean black ink outlines of even weight around every shape, flat bright colours with at most one soft shade per colour, crisp folk-art patterns (small flowers, dots, stripes, borders) drawn as clear shapes, warm lights as small yellow dots. Big simple shapes, sharp edges. Nothing blurry, no glow haze, no painterly texture, no photorealism, no 3D-render look, no tiny noisy detail. The light on the stage is warm, never tinted blue.

Front view at eye level, straight on, centred. The stage piece fills about 85% of the picture width, with an even band of background on all four sides; nothing touches the picture edges.

Everything around the stage piece is flat pure blue #0000FF: one even colour with no shadow, glow, floor or gradient on it, so it can be cut out. Nothing on the stage itself is blue.

No people, no text, no letters, no numbers, no watermark, no logo, no border. Landscape 3:2.
```

## 8. `reception-drape` (green key)

Attach: `style/S2-haldi-drape.png`, `style/S1-haldi-backdrop.png`, `reception/B-stage-in-our-style.png`

```
Draw one silk drape for the top-left corner of a screen, made the same way as the drape in picture S2: ivory silk with a deep maroon inner lining, falling from the top edge, gathered about halfway down by a gold rope with a gold tassel, then falling in folds to a point. A long string of white jasmine hangs along its inner (right) edge, with a small gold lantern hanging from the tie. Its colours match the ivory-and-maroon stage in the third picture.

Art style: copy the drawing style of pictures S1 and S2 exactly. A hand-drawn Bengali wedding-invitation illustration: bold, clean black ink outlines of even weight around every shape, flat bright colours with at most one soft shade per colour, crisp folk-art patterns drawn as clear shapes. Big simple shapes, sharp edges. Nothing blurry, no glow haze, no painterly texture, no photorealism, no 3D-render look.

The drape touches the top edge and the left edge of the picture and hangs down to about 85% of the picture height. It is a left-corner piece; the site mirrors it for the right corner.

Everything else is flat pure green #00FF00: one even colour with no shadow, glow or gradient on it, so it can be cut out.

No people, no text, no letters, no watermark, no logo, no border. Portrait 9:16.
```

## 9. `reception-hanging` (blue key)

Attach: `style/S1-haldi-backdrop.png`, `style/S2-haldi-drape.png`, `reception/B-stage-in-our-style.png`

```
Draw strands that hang from the top edge of a screen: an ivory-and-gold rail across the very top, with strands of white jasmine of different lengths hanging from it, small red roses tied into the strands here and there, and strings of small warm light bulbs swagging between them. The longest strands reach about 60% of the picture height.

Art style: copy the drawing style of pictures S1 and S2 exactly. A hand-drawn Bengali wedding-invitation illustration: bold, clean black ink outlines of even weight around every shape, flat bright colours with at most one soft shade per colour, warm lights as small yellow dots. Big simple shapes, sharp edges. Nothing blurry, no glow haze, no painterly texture, no photorealism, no 3D-render look.

The rail touches the top edge and runs out through the left and right edges. Below the strands is only background. The left and right ends match, so the strip can repeat side by side.

Everything else is flat pure blue #0000FF: one even colour with no shadow, glow or gradient on it, so it can be cut out. Nothing in the strands is blue.

No people, no text, no letters, no watermark, no logo, no border. Very wide: 21:9 (16:9 if 21:9 is not available).
```

## 10. `reception-urn` (blue key)

Attach: `style/S1-haldi-backdrop.png`, `reception/B-stage-in-our-style.png`, `reception/C-stays-lanterns.png`

```
Draw one tall flower stand as a piece standing on its own: a tall ivory pedestal with a gold rim, holding a white urn overflowing with red roses, pink roses and white lilies with dark green leaves, and three white pillar candles of different heights, lit, at its foot. Its colours match the ivory-and-maroon stage in the second picture and the gold lanterns in the third picture.

Art style: copy the drawing style of picture S1 exactly. A hand-drawn Bengali wedding-invitation illustration: bold, clean black ink outlines of even weight around every shape, flat bright colours with at most one soft shade per colour, crisp folk-art patterns drawn as clear shapes. Big simple shapes, sharp edges. Nothing blurry, no glow haze, no painterly texture, no photorealism, no 3D-render look.

Front view, straight on. The whole piece is visible, from the top flowers to the bottom of the pedestal, with an even band of background around it; nothing touches the picture edges. No floor and no shadow under it.

Everything around it is flat pure blue #0000FF: one even colour with no shadow, glow or gradient on it, so it can be cut out. Nothing in the piece is blue.

No people, no text, no letters, no watermark, no logo, no border. Portrait 2:3.
```
