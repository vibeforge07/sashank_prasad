# Final image sheet: every picture still to make

One place for every picture the site still needs. New needs get added at the bottom (section **Z**), so this file stays the single list.
When everything is in, generate them all in one go, save each PNG into `reference stage/done/` under its exact name, and tell Claude. Claude keys, places and animates them.

Last updated: 27 Nov 2026. **26 pictures to make + 1 you supply (couple photo).**

## Summary

| # | Name | Scene | Key | Shape | Why it is needed |
|---|---|---|---|---|---|
| A1 | `date-arch-tall` | Date page (phone) | green | portrait 9:16 | the page is a plain gradient; a carved jharokha arch frames the scratch tiles |
| A2 | `date-arch-wide` | Date page (desktop) | green | landscape 16:9 | same arch, wide, for desktop |
| A3 | `date-velvet-tile` | Date page | none (full tile) | square 1:1 | the plain background becomes indigo velvet with gold zari buti |
| A4 | `date-ledge` | Date page | blue | very wide 21:9 | a marble ledge with brass diyas along the bottom, like the client's video |
| A5 | `date-divider` | Date page | green | very wide 4:1 | gold filigree ornament under "The Date", like the client's video |
| A6 | `date-corner` | Date page | blue | square 1:1 | gold corner ornament, used at all four corners of the calendar card |
| B1 | `sky-sparkle-tile` | Sangeet, Wedding, Reception, Date | green | square 1:1 | the night skies are flat colour; a layer of gold sparkles gives them texture |
| C1 | `sangeet-floor` | Sangeet | green | very wide 21:9 | the stage floats on empty purple; a dance floor gives it ground |
| C2 | `sangeet-garden` | Sangeet | blue | very wide 21:9 | the middle is empty; a garden of fairy-light trees behind the stage |
| C3 | `sangeet-music` | Sangeet | blue | landscape 3:2 | dhol and harmonium at the side, so the corner is not bare |
| D1 | `wedding-city-art` | Wedding | green | landscape 3:2 | desktop has a big empty navy middle; the Kolkata + Jamshedpur skyline fills it |
| D2 | `wedding-floor` | Wedding | blue | very wide 21:9 | the plain red band becomes a carpet with white alpana |
| E1 | `reception-stage-small` | Reception | blue | landscape 3:2 | Reception still has the old big stage with a faded mask |
| E2 | `reception-drape` | Reception | green | portrait 9:16 | drapes at the top corners, like Sangeet and Wedding |
| E3 | `reception-hanging` | Reception | blue | very wide 21:9 | strands across the top |
| E4 | `reception-urn` | Reception | blue | portrait 2:3 | flower stands at the sides |
| E5 | `reception-floor` | Reception | blue | very wide 21:9 | the plain red band becomes a marble floor with an aisle carpet |
| E6 | `reception-wall` | Reception | green | very wide 21:9 | the empty middle behind the stage becomes the hall's back wall |
| F1 | `hero-groom` | First page | green | portrait 2:3 | groom in casual clothes (now in wedding clothes) |
| F2 | `hero-bride` | First page | green | portrait 2:3 | bride in casual clothes (now in bridal red) |
| F3 | `tilak-groom` | Tilak | blue | same as A | bottle-green kurta instead of cream |
| F4 | `briddhi-family` | Briddhi | blue | same as A | bride in a pink tant saree, no crown |
| F5 | `mehendi-couple` | Mehendi | blue | same as A | green lehenga and peach kurta |
| F6 | `aibur-family` | Aiburobhaat | green | same as A | bride in a magenta Banarasi, no crown |
| F7 | `haldi-couple-full` | Haldi | blue | same as A | yellow haldi clothes |
| F8 | `sangeet-bride` | Sangeet | green | same as A | lavender lehenga instead of red |
| G1 | `couple-photo` | Envelope card | none | portrait | **you supply this**; put it in `art/raw/couple-photo.png` |

## How to make each picture

1. A fresh generation (new chat) for every picture.
2. Attach the files the block names, in that order. If the tool cannot take image attachments, stop: never make one from the text alone.
3. Paste the block word for word.
4. Save as PNG, at the largest size the tool gives, as `reference stage/done/<name>.png`.
5. Check it against the list below. At most 3 tries; then keep the best and note what is wrong.

Pictures named `D-now-*` in the folders show how the page looks today. Look at them, **never attach them**.
The client's video frames in `13-final/date/` show a phone held in a hand; they are for layout only. Never draw a hand or a phone.

Style pictures used below:

- `12-clean-scenes/style/S1-haldi-backdrop.png`: the line and colour every picture must copy
- `12-clean-scenes/style/S2-haldi-drape.png`: the drape and strip style
- `12-clean-scenes/<scene>/B-stage-in-our-style.png`: each scene's stage, for its colours

## Check every picture before saving

1. **Line and colour:** bold, clean black outlines of even weight and flat colours with at most one soft shade, exactly like S1. Crisp edges, nothing blurry, hazy, glowing or painterly.
2. **Clean key:** everything that is not the piece is ONE flat key colour, with no shadow, glow, gradient, floor line or reflection. The piece itself has none of the key colour in it.
3. **Edges:** only the edges the block names are touched. Nothing else is cut off.
4. **Nothing extra:** no people (except in F), no text, letters, numbers, watermark, logo, border or frame.
5. **Strips repeat:** in every very wide strip the left and right ends match, so it can repeat side by side.

---

# A. The date page

Today it is a plain purple gradient with a borrowed toran, lanterns and grass. The client's video (saath.studio) has a glittering night sky, a gold filigree under "The Date", and, before it, a carved arch with a lamp on a marble ledge. These six pictures bring that richness in, in our own art style.

## A1. `date-arch-tall` (green key)

Attach: `12-clean-scenes/style/S1-haldi-backdrop.png`, `13-final/date/A-client-arch.png`, `13-final/date/B-client-lamp.png`

```
Draw a carved Rajasthani jharokha arch that frames the whole of a phone screen, like the arch in pictures 2 and 3 but in the drawing style of picture S1. The frame is warm terracotta and gold, covered in carved folk patterns: small flowers, paisleys and vines in neat rows, with small niches holding lit diyas running up both sides (like picture 3). The opening in the middle is a tall scalloped (cusped) Mughal arch.

The frame touches all four edges of the picture. The arch opening is big: it takes the middle 72% of the width and runs from 16% below the top down to 8% above the bottom. Inside the opening there is nothing at all: it is flat key colour, because the date and the calendar sit there on the site.

Art style: copy the drawing style of picture S1 exactly. A hand-drawn Bengali wedding-invitation illustration: bold, clean black ink outlines of even weight around every shape, flat bright colours with at most one soft shade per colour, crisp folk-art patterns drawn as clear shapes, warm lights as small yellow dots. Big simple shapes, sharp edges. Nothing blurry, no glow haze, no painterly texture, no photorealism, no 3D-render look. Do not copy the photo look of pictures 2 and 3, only their layout.

Front view, straight on, perfectly symmetrical left to right.

The arch opening is flat pure green #00FF00: one even colour with no shadow, glow or gradient on it, so it can be cut out. Nothing in the frame is green.

No people, no hands, no phone, no text, no letters, no numbers, no watermark, no logo. Portrait 9:16.
```

## A2. `date-arch-wide` (green key)

Attach: `12-clean-scenes/style/S1-haldi-backdrop.png`, `13-final/date/A-client-arch.png`, `13-final/date/B-client-lamp.png`

```
Draw a carved Rajasthani jharokha frame for a wide desktop screen, like the arch in pictures 2 and 3 but in the drawing style of picture S1. The frame is warm terracotta and gold, covered in carved folk patterns: small flowers, paisleys and vines in neat rows, with small niches holding lit diyas running up both sides (like picture 3). The opening is a wide scalloped (cusped) Mughal arch: a low, broad arch, wider than it is tall.

The frame touches all four edges of the picture. The opening is big: it takes the middle 80% of the width and runs from 14% below the top down to 8% above the bottom. Inside the opening there is nothing at all: it is flat key colour, because the date and the calendar sit there side by side on the site.

Art style: copy the drawing style of picture S1 exactly. A hand-drawn Bengali wedding-invitation illustration: bold, clean black ink outlines of even weight around every shape, flat bright colours with at most one soft shade per colour, crisp folk-art patterns drawn as clear shapes, warm lights as small yellow dots. Big simple shapes, sharp edges. Nothing blurry, no glow haze, no painterly texture, no photorealism, no 3D-render look. Do not copy the photo look of pictures 2 and 3, only their layout.

Front view, straight on, perfectly symmetrical left to right.

The arch opening is flat pure green #00FF00: one even colour with no shadow, glow or gradient on it, so it can be cut out. Nothing in the frame is green.

No people, no hands, no phone, no text, no letters, no numbers, no watermark, no logo. Landscape 16:9.
```

## A3. `date-velvet-tile` (no key, fills the frame)

Attach: `12-clean-scenes/style/S1-haldi-backdrop.png`, `13-final/date/C-client-date.png`

```
Draw a seamless repeating pattern tile: deep indigo velvet (#1c1450 to #24185c) covered in a small, sparse gold zari buti pattern, like the woven butis on a Banarasi saree: tiny paisleys and four-petal flowers in neat staggered rows, with a few tiny gold sparkle dots between them. It is a quiet background behind text, so the pattern is small, low in contrast and evenly spread, never busy. The deep indigo must stay the main colour, like the sky in picture 2.

Art style: the clean flat drawing of picture S1: crisp shapes, flat colour, thin dark outlines on the gold butis. No blur, no photorealism, no noise, no shading across the tile.

The tile must repeat seamlessly: the pattern on the left edge continues on the right edge, the top continues at the bottom. No border, no frame, no vignette, no darker corners. The whole square is evenly lit.

No people, no text, no letters, no numbers, no watermark, no logo. Square 1:1.
```

## A4. `date-ledge` (blue key)

Attach: `12-clean-scenes/style/S1-haldi-backdrop.png`, `12-clean-scenes/style/S2-haldi-drape.png`, `13-final/date/B-client-lamp.png`

```
Draw a long white marble ledge that runs along the bottom edge of a screen, like the ledge in picture 3 but in the drawing style of picture S1: a white marble top with a thin gold inlay border along its front, and below it a band of carved marble with a row of small lotus shapes. On the ledge stand lit brass diyas spaced evenly along its length (five across the width), each with a small orange flame, with marigold flowers and a few rose petals scattered between them.

The ledge touches the bottom edge and runs out through the left and right edges. It fills the bottom 30% of the picture; above the diya flames is only background. The left and right ends match, so the strip can repeat side by side.

Art style: copy the drawing style of pictures S1 and S2 exactly. A hand-drawn Bengali wedding-invitation illustration: bold, clean black ink outlines of even weight around every shape, flat bright colours with at most one soft shade per colour, crisp folk-art patterns drawn as clear shapes, flames drawn as clean flat shapes. Nothing blurry, no glow haze, no painterly texture, no photorealism, no 3D-render look.

Everything above the ledge is flat pure blue #0000FF: one even colour with no shadow, glow or gradient on it, so it can be cut out. Nothing in the ledge is blue.

No people, no hands, no text, no letters, no watermark, no logo. Very wide: 21:9 (16:9 if 21:9 is not available).
```

## A5. `date-divider` (green key)

Attach: `12-clean-scenes/style/S1-haldi-backdrop.png`, `13-final/date/C-client-date.png`

```
Draw a gold filigree ornament that sits under a title, like the ornament under "The Date" in picture 2 but in the drawing style of picture S1: a small round gold medallion with a ruby-red centre in the middle, with symmetrical gold scrolls, curls and small leaves running out to each side and thinning to a fine point at both ends.

It is long and thin: about four times as wide as it is tall, perfectly symmetrical left to right, centred, with an even band of background around it. Nothing touches the picture edges.

Art style: bold, clean dark outlines of even weight, flat gold with one soft shade, crisp shapes. Nothing blurry, no glow, no photorealism, no 3D-render look.

Everything around it is flat pure green #00FF00: one even colour with no shadow, glow or gradient on it, so it can be cut out. Nothing in the ornament is green.

No text, no letters, no watermark, no logo. Very wide: 4:1 (or the widest shape available).
```

## A6. `date-corner` (blue key)

Attach: `12-clean-scenes/style/S1-haldi-backdrop.png`, `12-clean-scenes/style/S2-haldi-drape.png`

```
Draw one gold corner ornament for the top-left corner of a card: a gold paisley (kalka) curling out of the corner, with small marigold and jasmine flowers and two small leaves tucked into it, and a thin gold line running a short way along the top and along the left side from the corner. It is a left corner piece; the site mirrors and turns it for the other three corners.

The ornament sits in the top-left of the picture and touches the top edge and the left edge only. It takes about 70% of the width and 70% of the height.

Art style: copy the drawing style of pictures S1 and S2 exactly: bold, clean black ink outlines of even weight, flat bright colours with at most one soft shade per colour, crisp shapes. Nothing blurry, no glow haze, no photorealism, no 3D-render look.

Everything else is flat pure blue #0000FF: one even colour with no shadow, glow or gradient on it, so it can be cut out. Nothing in the ornament is blue.

No text, no letters, no watermark, no logo. Square 1:1.
```

---

# B. Shared

## B1. `sky-sparkle-tile` (green key)

Attach: `12-clean-scenes/style/S1-haldi-backdrop.png`, `13-final/date/C-client-date.png`

```
Draw a seamless repeating tile of sparkles to lay over a night sky: small gold four-point sparkle stars of three sizes, tiny gold and cream dots, and a few small eight-point folk stars, scattered evenly but irregularly, sparse, with plenty of empty space between them, like the glitter in the sky of picture 2 but drawn as clean flat shapes in the style of picture S1.

Only the sparkles are drawn. Everything between them is flat pure green #00FF00: one even colour with no shadow, glow, haze or gradient on it, so it can be cut out. No glow around the sparkles. Nothing in the sparkles is green.

The tile must repeat seamlessly: sparkles cut by the left edge continue on the right edge, the top continues at the bottom. No border, no frame.

No text, no letters, no watermark, no logo. Square 1:1.
```

---

# C. Sangeet

Today: strands and drapes at the top, the small stage and the dancers at the bottom, and in between a flat purple sky. The stage stands on nothing (see `13-final/sangeet/D-now-desktop.png`).

## C1. `sangeet-floor` (green key)

Attach: `12-clean-scenes/style/S1-haldi-backdrop.png`, `12-clean-scenes/sangeet/B-stage-in-our-style.png`, `12-clean-scenes/style/S4-haldi-whole-look.png`

```
Draw a dance floor that runs along the bottom edge of a screen, seen from the front at eye level: a polished floor in deep plum and gold, laid in a big folk pattern of gold lotus and star shapes, with a border of tiny warm fairy lights along its back edge, and lavender, white and pink flower petals scattered over it. Its colours match the lavender-and-gold stage in picture 2. It plays the part the terrace floor plays in picture 3.

The floor touches the bottom edge and runs out through the left and right edges. It fills the bottom 35% of the picture; its back edge is a straight, level line. Above it is only background. The left and right ends match, so the strip can repeat side by side.

Art style: copy the drawing style of picture S1 exactly. A hand-drawn Bengali wedding-invitation illustration: bold, clean black ink outlines of even weight around every shape, flat bright colours with at most one soft shade per colour, crisp folk-art patterns drawn as clear shapes, lights as small yellow dots. Nothing blurry, no glow haze, no reflections, no painterly texture, no photorealism, no 3D-render look.

Everything above the floor is flat pure green #00FF00: one even colour with no shadow, glow or gradient on it, so it can be cut out. Nothing in the floor is green.

No people, no text, no letters, no watermark, no logo. Very wide: 21:9 (16:9 if 21:9 is not available).
```

## C2. `sangeet-garden` (blue key)

Attach: `12-clean-scenes/style/S1-haldi-backdrop.png`, `12-clean-scenes/sangeet/B-stage-in-our-style.png`, `12-clean-scenes/style/S3-mehendi-whole-look.png`

```
Draw the garden behind an outdoor sangeet at night, as a strip along the bottom of a screen: a row of round, neatly clipped trees, each wrapped in strings of tiny warm fairy lights, with a low hedge in front of them, and strings of lavender and pink paper lanterns swagging between the trees. The trees are dark forest green and deep plum, lit warm gold by the lights. Its colours sit behind the lavender-and-gold stage in picture 2, which stands in front of the middle of this strip.

The middle third is lower than the sides, because the stage stands there: only the hedge and small trees in the middle, taller trees at the two sides.

The strip touches the bottom edge and runs out through the left and right edges. The tallest trees reach about 65% of the picture height; above them is only background. The left and right ends match, so the strip can repeat side by side.

Art style: copy the drawing style of picture S1 exactly. A hand-drawn Bengali wedding-invitation illustration: bold, clean black ink outlines of even weight around every shape, flat colours with at most one soft shade per colour, lights as small yellow dots. Big simple shapes, sharp edges. Nothing blurry, no glow haze, no painterly texture, no photorealism, no 3D-render look.

Everything above the garden is flat pure blue #0000FF: one even colour with no shadow, glow or gradient on it, so it can be cut out. Nothing in the garden is blue; the night shades are plum and forest green, never blue.

No people, no text, no letters, no watermark, no logo. Very wide: 21:9 (16:9 if 21:9 is not available).
```

## C3. `sangeet-music` (blue key)

Attach: `12-clean-scenes/style/S1-haldi-backdrop.png`, `12-clean-scenes/sangeet/B-stage-in-our-style.png`

```
Draw the music corner of a sangeet as one piece standing on its own: a dhol (a barrel drum with a red-and-gold body and rope lacing) lying on a low lavender cushion, a wooden harmonium with ivory keys beside it, a pair of small brass manjira cymbals, and a marigold and jasmine garland draped over the dhol. Its colours match the lavender-and-gold stage in picture 2.

Front view, slightly from above. The whole piece is visible, with an even band of background around it; nothing touches the picture edges. No floor and no shadow under it.

Art style: copy the drawing style of picture S1 exactly. A hand-drawn Bengali wedding-invitation illustration: bold, clean black ink outlines of even weight around every shape, flat bright colours with at most one soft shade per colour, crisp folk-art patterns drawn as clear shapes. Nothing blurry, no glow haze, no painterly texture, no photorealism, no 3D-render look.

Everything around it is flat pure blue #0000FF: one even colour with no shadow, glow or gradient on it, so it can be cut out. Nothing in the piece is blue.

No people, no text, no letters, no watermark, no logo. Landscape 3:2.
```

---

# D. Wedding

Today: the toran, the drapes, the banana plants and the stage are in, but on desktop the whole middle is empty navy, and the floor is a plain red band (see `13-final/wedding/D-now-desktop.png`).

## D1. `wedding-city-art` (green key)

Attach: `12-clean-scenes/style/S1-haldi-backdrop.png`, `4-wedding-city/A-kolkata-landmarks.png`, `4-wedding-city/B-jamshedpur-landmarks.png`, `4-wedding-city/C-style-night-buildings.png`

```
Draw a wide night skyline behind an outdoor wedding, where the bride's Kolkata meets the groom's Jamshedpur, as a strip along the bottom of the picture. Use pictures 2, 3 and 4 for the landmarks and the lit-building look only; copy the drawing style of picture S1.

Left third, Kolkata: Howrah Bridge lit with strings of lights, drawn like picture 2, and the white marble dome of the Victoria Memorial glowing softly beside it, with a few old Kolkata rooftops.

Right third, Jamshedpur: the Tata Steel plant with its red-and-white striped chimneys, a warm furnace glow and soft white smoke, the glass diamond monument lit from inside, and the Dalma hills as dark blue-green shapes behind, all drawn like picture 3.

Middle third: low, because the wedding stage stands in front of it. Only dark trees and a low hedge there, nothing tall.

Across the whole bottom: a neat garden hedge full of tiny warm fairy lights, with marigold garlands and small brass diyas along its top so it reads as a wedding.

Art style: a hand-drawn Bengali wedding-invitation illustration: bold, clean black ink outlines of even weight around every shape, flat colours with at most one soft shade per colour, buildings glowing warm gold and orange against the night, window lights as small yellow dots. Nothing blurry, no glow haze, no painterly texture, no photorealism, no 3D-render look.

Night colours only: navy, deep teal, warm gold. No sun, no moon, no clouds, no river, no road, no vehicles.

The skyline fills the full width and the lower half of the picture; the hedge sits on the bottom edge. The left and right ends are calm (trees and hedge) so they can meet the drapes. Everything above the skyline is flat pure green #00FF00: one even colour with no shadow, glow or gradient on it, so it can be cut out. Leaves are deep forest green, never bright lime.

No people, no text, no letters, no watermark, no logo, no border. Landscape 3:2.
```

## D2. `wedding-floor` (blue key)

Attach: `12-clean-scenes/style/S1-haldi-backdrop.png`, `12-clean-scenes/wedding/B-stage-in-our-style.png`, `12-clean-scenes/style/S4-haldi-whole-look.png`

```
Draw the floor of a Bengali wedding mandap that runs along the bottom edge of a screen, seen from the front at eye level: a deep red carpet with a wide white alpana border drawn along its back edge (lotus, conch and paisley shapes in clean white lines), a thin gold band along the border, and orange and yellow marigold petals scattered over the carpet. Its colours match the maroon-and-gold stage in picture 2. It plays the part the terrace floor plays in picture 3.

The floor touches the bottom edge and runs out through the left and right edges. It fills the bottom 30% of the picture; its back edge is a straight, level line. Above it is only background. The left and right ends match, so the strip can repeat side by side.

Art style: copy the drawing style of picture S1 exactly. A hand-drawn Bengali wedding-invitation illustration: bold, clean black ink outlines of even weight around every shape, flat bright colours with at most one soft shade per colour, crisp folk-art patterns drawn as clear shapes. Nothing blurry, no glow haze, no reflections, no painterly texture, no photorealism, no 3D-render look.

Everything above the floor is flat pure blue #0000FF: one even colour with no shadow, glow or gradient on it, so it can be cut out. Nothing in the floor is blue.

No people, no text, no letters, no watermark, no logo. Very wide: 21:9 (16:9 if 21:9 is not available).
```

---

# E. Reception

Today: the old big stage picture with its faded mask, a plain dark sky and a plain red floor (see `13-final/reception/D-now-*.png`). E1 to E4 rebuild it like Sangeet and Wedding; E5 and E6 fill the floor and the empty middle.

## E1. `reception-stage-small` (blue key)

Attach: `12-clean-scenes/style/S1-haldi-backdrop.png`, `12-clean-scenes/reception/A-client-stage.png`, `12-clean-scenes/reception/B-stage-in-our-style.png`

```
Draw the client's reception stage as one small stage piece standing on its own, in the same way picture S1 shows the Haldi backdrop as a single piece. Picture A is the client's real reception hall; picture B is its stage already redrawn in our site's style. Keep the stage's design, but no room around it: no ceiling drapes, no side curtains, no chandelier, no guest tables, no wall, no floor around it.

Keep these pieces: a big arch of red, pink and white lilies and roses with dark green leaves; three small gold lanterns hanging inside the arch over a deep maroon drape with strings of tiny warm lights; ivory lattice screens with rounded tops on both sides of the arch; white flower urns on ivory pedestals; little clusters of white candles; an ivory-and-gold sofa with two maroon cushions in the middle; a low maroon stage platform.

Art style: copy the drawing style of picture S1 exactly. A hand-drawn Bengali wedding-invitation illustration: bold, clean black ink outlines of even weight around every shape, flat bright colours with at most one soft shade per colour, crisp folk-art patterns (small flowers, dots, stripes, borders) drawn as clear shapes, warm lights as small yellow dots. Big simple shapes, sharp edges. Nothing blurry, no glow haze, no painterly texture, no photorealism, no 3D-render look, no tiny noisy detail. The light on the stage is warm, never tinted blue.

Front view at eye level, straight on, centred. The stage piece fills about 85% of the picture width, with an even band of background on all four sides; nothing touches the picture edges.

Everything around the stage piece is flat pure blue #0000FF: one even colour with no shadow, glow, floor or gradient on it, so it can be cut out. Nothing on the stage itself is blue.

No people, no text, no letters, no numbers, no watermark, no logo, no border. Landscape 3:2.
```

## E2. `reception-drape` (green key)

Attach: `12-clean-scenes/style/S2-haldi-drape.png`, `12-clean-scenes/style/S1-haldi-backdrop.png`, `12-clean-scenes/reception/B-stage-in-our-style.png`

```
Draw one silk drape for the top-left corner of a screen, made the same way as the drape in picture S2: ivory silk with a deep maroon inner lining, falling from the top edge, gathered about halfway down by a gold rope with a gold tassel, then falling in folds to a point. A long string of white jasmine hangs along its inner (right) edge, with a small gold lantern hanging from the tie. Its colours match the ivory-and-maroon stage in the third picture.

Art style: copy the drawing style of pictures S1 and S2 exactly. A hand-drawn Bengali wedding-invitation illustration: bold, clean black ink outlines of even weight around every shape, flat bright colours with at most one soft shade per colour, crisp folk-art patterns drawn as clear shapes. Big simple shapes, sharp edges. Nothing blurry, no glow haze, no painterly texture, no photorealism, no 3D-render look.

The drape touches the top edge and the left edge of the picture and hangs down to about 85% of the picture height. It is a left-corner piece; the site mirrors it for the right corner.

Everything else is flat pure green #00FF00: one even colour with no shadow, glow or gradient on it, so it can be cut out.

No people, no text, no letters, no watermark, no logo, no border. Portrait 9:16.
```

## E3. `reception-hanging` (blue key)

Attach: `12-clean-scenes/style/S1-haldi-backdrop.png`, `12-clean-scenes/style/S2-haldi-drape.png`, `12-clean-scenes/reception/B-stage-in-our-style.png`

```
Draw strands that hang from the top edge of a screen: an ivory-and-gold rail across the very top, with strands of white jasmine of different lengths hanging from it, small red roses tied into the strands here and there, and strings of small warm light bulbs swagging between them. The longest strands reach about 60% of the picture height.

Art style: copy the drawing style of pictures S1 and S2 exactly. A hand-drawn Bengali wedding-invitation illustration: bold, clean black ink outlines of even weight around every shape, flat bright colours with at most one soft shade per colour, warm lights as small yellow dots. Big simple shapes, sharp edges. Nothing blurry, no glow haze, no painterly texture, no photorealism, no 3D-render look.

The rail touches the top edge and runs out through the left and right edges. Below the strands is only background. The left and right ends match, so the strip can repeat side by side.

Everything else is flat pure blue #0000FF: one even colour with no shadow, glow or gradient on it, so it can be cut out. Nothing in the strands is blue.

No people, no text, no letters, no watermark, no logo, no border. Very wide: 21:9 (16:9 if 21:9 is not available).
```

## E4. `reception-urn` (blue key)

Attach: `12-clean-scenes/style/S1-haldi-backdrop.png`, `12-clean-scenes/reception/B-stage-in-our-style.png`, `12-clean-scenes/reception/C-stays-lanterns.png`

```
Draw one tall flower stand as a piece standing on its own: a tall ivory pedestal with a gold rim, holding a white urn overflowing with red roses, pink roses and white lilies with dark green leaves, and three white pillar candles of different heights, lit, at its foot. Its colours match the ivory-and-maroon stage in the second picture and the gold lanterns in the third picture.

Art style: copy the drawing style of picture S1 exactly. A hand-drawn Bengali wedding-invitation illustration: bold, clean black ink outlines of even weight around every shape, flat bright colours with at most one soft shade per colour, crisp folk-art patterns drawn as clear shapes. Big simple shapes, sharp edges. Nothing blurry, no glow haze, no painterly texture, no photorealism, no 3D-render look.

Front view, straight on. The whole piece is visible, from the top flowers to the bottom of the pedestal, with an even band of background around it; nothing touches the picture edges. No floor and no shadow under it.

Everything around it is flat pure blue #0000FF: one even colour with no shadow, glow or gradient on it, so it can be cut out. Nothing in the piece is blue.

No people, no text, no letters, no watermark, no logo, no border. Portrait 2:3.
```

## E5. `reception-floor` (blue key)

Attach: `12-clean-scenes/style/S1-haldi-backdrop.png`, `12-clean-scenes/reception/B-stage-in-our-style.png`, `12-clean-scenes/style/S4-haldi-whole-look.png`

```
Draw the floor of a grand reception hall that runs along the bottom edge of a screen, seen from the front at eye level: an ivory marble floor laid in big squares with thin gold lines, a deep maroon carpet with a gold border running across it, and a few red and pink rose petals on the carpet. Its colours match the ivory-and-maroon stage in picture 2. It plays the part the terrace floor plays in picture 3.

The floor touches the bottom edge and runs out through the left and right edges. It fills the bottom 30% of the picture; its back edge is a straight, level line. Above it is only background. The left and right ends match, so the strip can repeat side by side.

Art style: copy the drawing style of picture S1 exactly. A hand-drawn Bengali wedding-invitation illustration: bold, clean black ink outlines of even weight around every shape, flat colours with at most one soft shade per colour, crisp patterns drawn as clear shapes. Nothing blurry, no glow haze, no reflections, no painterly texture, no photorealism, no 3D-render look.

Everything above the floor is flat pure blue #0000FF: one even colour with no shadow, glow or gradient on it, so it can be cut out. Nothing in the floor is blue.

No people, no text, no letters, no watermark, no logo. Very wide: 21:9 (16:9 if 21:9 is not available).
```

## E6. `reception-wall` (green key)

Attach: `12-clean-scenes/style/S1-haldi-backdrop.png`, `12-clean-scenes/reception/A-client-stage.png`, `12-clean-scenes/reception/B-stage-in-our-style.png`

```
Draw the back wall of a grand hotel reception hall at night, as a strip along the bottom of a screen: deep maroon walls with ivory pillars and gold trim, tall arched windows between the pillars showing a dark night outside with a few stars, a brass wall sconce with a warm light beside each window, and ivory swags of fabric with jasmine strings along the top of the wall. Its colours match the ivory-and-maroon stage in pictures 2 and 3, which stands in front of the middle of this wall.

The strip touches the bottom edge and runs out through the left and right edges. The wall reaches about 70% of the picture height; above its top edge is only background. The left and right ends match, so the strip can repeat side by side.

Art style: copy the drawing style of picture S1 exactly. A hand-drawn Bengali wedding-invitation illustration: bold, clean black ink outlines of even weight around every shape, flat colours with at most one soft shade per colour, crisp patterns drawn as clear shapes, lights as small yellow dots. Nothing blurry, no glow haze, no painterly texture, no photorealism, no 3D-render look.

Everything above the wall is flat pure green #00FF00: one even colour with no shadow, glow or gradient on it, so it can be cut out. Nothing in the wall is green: no plants.

No people, no chairs, no tables, no text, no letters, no watermark, no logo. Very wide: 21:9 (16:9 if 21:9 is not available).
```

---

# F. New clothes for the couple

A different outfit for every event, casual on the first page. The wedding and the reception stay as they are.
**Check before saving:** same faces and pose as now; only the clothes changed; no crown except at the wedding; flat key background.

## F1. `hero-groom` (green key)

Attach: `5-first-page/A-groom-now.png`, `5-first-page/B-bride-now.png`

```
Draw the man in picture A again, in the same art style (dark-brown ink outlines, flat colour, soft cel shading) and with the same face, hair and skin. Full body, standing, from head to shoes, feet near the bottom edge.

He is dressed casually for an everyday outing, not for a wedding: a sky-blue linen shirt with the sleeves rolled to the elbows, beige chinos, brown loafers and a simple wristwatch. No topor, no turban, no garland, no dupatta, no tilak.

He stands turned three-quarters towards the right edge of the picture, looking to the right with a warm smile, as if at his bride standing beside him. One hand in his trouser pocket, the other relaxed at his side.

Background: flat pure green #00FF00, one even colour with no shadow or gradient. No text, no watermark, no border. Portrait 1024 x 1536.
```

## F2. `hero-bride` (green key)

Attach: `5-first-page/A-groom-now.png`, `5-first-page/B-bride-now.png`

```
Draw the woman in picture B again, in the same art style (dark-brown ink outlines, flat colour, soft cel shading) and with the same face, hair and skin. Full body, standing, from head to shoes, feet near the bottom edge.

She is dressed casually for an everyday outing, not as a bride: a mustard-yellow cotton kurta with small white block prints, white palazzo trousers, a light peach dupatta over one shoulder, small silver jhumkas, a few glass bangles, a small red bindi, hair open and wavy. No crown, no mukut, no veil, no garland, no red bridal saree, no heavy jewellery.

She stands turned three-quarters towards the left edge of the picture, looking to the left with a shy smile, as if at her groom standing beside her. Both hands lightly hold the end of her dupatta.

Draw her the same height as the man in picture A.

Background: flat pure green #00FF00, one even colour with no shadow or gradient. No text, no watermark, no border. Portrait 1024 x 1536.
```

## F3. `tilak-groom` (blue key)

Attach: `6-tilak/A-now.png`

```
Edit picture A. Keep everything exactly as it is: the same people, the same faces, hair and skin, the same pose, hands and expression, the same size and position in the frame, and the same art style (dark-brown ink outlines, flat colour, soft cel shading). Change only the clothes and jewellery, as follows:

He wears a bottle-green raw-silk kurta with small gold buttons and a thin gold border at the collar, an off-white dhoti, and a thin cream stole over one shoulder. No cream kurta, no orange or red dupatta.

Background: flat pure blue #0000FF, one even colour with no shadow or gradient. No text, no watermark, no border. Same picture size as A.
```

## F4. `briddhi-family` (blue key)

Attach: `7-briddhi/A-now.png`

```
Edit picture A. Keep everything exactly as it is: the same people, the same faces, hair and skin, the same pose, hands and expression, the same size and position in the frame, and the same art style (dark-brown ink outlines, flat colour, soft cel shading). Change only the clothes and jewellery, as follows:

Change only the bride (the young woman with the crown and the red veil). She now wears a pale pink cotton tant saree with a thin gold border, simple gold studs, a thin gold chain and a few bangles, hair in a low bun with a small string of jasmine. No crown, no mukut, no veil, no red bridal saree. Everyone else stays exactly the same.

Background: flat pure blue #0000FF, one even colour with no shadow or gradient. No text, no watermark, no border. Same picture size as A.
```

## F5. `mehendi-couple` (blue key)

Attach: `8-mehendi/A-now.png`

```
Edit picture A. Keep everything exactly as it is: the same people, the same faces, hair and skin, the same pose, hands and expression, the same size and position in the frame, and the same art style (dark-brown ink outlines, flat colour, soft cel shading). Change only the clothes and jewellery, as follows:

The bride wears a parrot-green lehenga with small mirror work and a pink dupatta, fresh-flower jewellery of marigold and jasmine, hair in a loose braid. No crown, no mukut, no veil, no red saree.

The groom wears a peach cotton kurta with a white churidar. No cream kurta, no yellow or orange dupatta.

Background: flat pure blue #0000FF, one even colour with no shadow or gradient. No text, no watermark, no border. Same picture size as A.
```

## F6. `aibur-family` (green key)

Attach: `9-aiburobhaat/A-now.png`

```
Edit picture A. Keep everything exactly as it is: the same people, the same faces, hair and skin, the same pose, hands and expression, the same size and position in the frame, and the same art style (dark-brown ink outlines, flat colour, soft cel shading). Change only the clothes and jewellery, as follows:

Change only the bride (the young woman in the middle with the crown). She now wears a deep magenta Banarasi silk saree with gold zari, gold jewellery, hair in a bun with a jasmine gajra. No crown, no mukut, no veil. Everyone else stays exactly the same.

Background: flat pure green #00FF00, one even colour with no shadow or gradient. No text, no watermark, no border. Same picture size as A.
```

## F7. `haldi-couple-full` (blue key)

Attach: `10-haldi/A-now.png`

```
Edit picture A. Keep everything exactly as it is: the same people, the same faces, hair and skin, the same pose, hands and expression, the same size and position in the frame, and the same art style (dark-brown ink outlines, flat colour, soft cel shading). Change only the clothes and jewellery, as follows:

Both are dressed for haldi. The groom wears a plain yellow cotton kurta and a white pyjama, with no red or orange dupatta. The bride wears a yellow-and-white cotton saree with fresh-flower jewellery of marigold and jasmine, hair in a loose bun with flowers. No crown, no mukut, no veil.

Keep the groom's arm, his hand and the haldi bowl exactly where they are now.

Background: flat pure blue #0000FF, one even colour with no shadow or gradient. No text, no watermark, no border. Same picture size as A.
```

## F8. `sangeet-bride` (green key)

Attach: `11-sangeet-bride/A-now.png`

```
Edit picture A. Keep everything exactly as it is: the same people, the same faces, hair and skin, the same pose, hands and expression, the same size and position in the frame, and the same art style (dark-brown ink outlines, flat colour, soft cel shading). Change only the clothes and jewellery, as follows:

She wears a lavender-and-silver lehenga with mirror work and a sheer lilac dupatta flying with the dance, silver jhumkas, hair open and flying with jasmine in it. No crown, no mukut, no red lehenga.

Background: flat pure green #00FF00, one even colour with no shadow or gradient. No text, no watermark, no border. Same picture size as A.
```

---

# G. You supply

## G1. `couple-photo`

The couple's picture for the envelope card. You make this one yourself. Save it as `art/raw/couple-photo.png` and tell Claude; it goes into the gold arch on the card (`npm run art -- couple-photo`).

---

# Z. Added later

New needs go here, one block each, in the same form as above.
